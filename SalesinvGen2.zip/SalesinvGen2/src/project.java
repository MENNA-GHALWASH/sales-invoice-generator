//problems i have :
//cant get the ui right
//dont know how to access table columns and rows to get their data : try get Invsdata
//how to properly align csv data into the invoice table?

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.*;

public class project extends JFrame implements ActionListener {
    private double invtotvalnum = 0;
    private int invoicenum = 1;
    private JTable InvsTable; //create table
    private JTable InvItemsTable;

    private String[] InvsTablecols = {"No.", "Date", "Customer", "Total"}; //table col names
    private String[][] Invsdata /*= new String[7][4]*/; //tables data
    private String[][] InvsItemsdata /*= new String[7][5]*/; //keep track

    private String[] InvsItemsTablecols = {"No.", "Item Name", "Item Price", "Count", " Item Total"};

    private JButton Create;
    private JButton Delete;
    private JButton Save;
    private JButton Cancel;
    private JLabel InvNo;
    private JLabel InvVal;
    private JLabel InvDate;
    private JLabel CustName;
    private JLabel InvTotal;
    private JLabel InvTotalVal, rightTabletitle, Lefttabletitle;
    private JTextField InvDt_txt;
    private JTextField CusName_txt;
    private JSplitPane testDP;
    private JMenuBar menuBar;
    private JMenuItem LoadFile;
    private JMenuItem SaveFile;
    private JMenu File;
    private JPanel right, left, input, righttbl, lefttbl, rightbuttons, leftbuttons;

    public project() {
        super("Sales invoice generator");
        setSize(700, 500);
        setLocation(200, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        menuBar = new JMenuBar();
        File = new JMenu("File");
        LoadFile = new JMenuItem("Load file", 'l');
        SaveFile = new JMenuItem("Save file", 's');
        SaveFile.setAccelerator(KeyStroke.getKeyStroke('S', KeyEvent.CTRL_DOWN_MASK));
        testDP = new JSplitPane();
        InvNo = new JLabel("Invoice Number ");
        InvDate = new JLabel("Invoice Date ");
        CustName = new JLabel("Customer Name ");
        InvTotal = new JLabel("Invoice Total ");
        String A = Integer.toString(invoicenum);
        InvVal = new JLabel(A);
        String B = Double.toString(invtotvalnum);
        InvTotalVal = new JLabel(B);
        InvDt_txt = new JTextField(20);
        CusName_txt = new JTextField(20);
        Create = new JButton("Create new Invoice");
        Delete = new JButton("Delete Invoice");
        Save = new JButton("Save");
        Cancel = new JButton("Cancel");
        right = new JPanel();
        left = new JPanel();
        input = new JPanel(); //done
        righttbl = new JPanel();
        lefttbl = new JPanel();
        rightbuttons = new JPanel();
        leftbuttons = new JPanel();
        rightTabletitle = new JLabel("Invoice items");
        Lefttabletitle = new JLabel("Invoices table");

        DefaultTableModel tm = new DefaultTableModel(Invsdata, InvsTablecols);
        InvsTable = new JTable(tm);

        DefaultTableModel tm2 = new DefaultTableModel(InvsItemsdata, InvsItemsTablecols);
        InvItemsTable = new JTable(tm2);

        setJMenuBar(menuBar); //adds the menu bar to the panel
        menuBar.add(File);
        File.add(LoadFile);
        File.add(SaveFile);

        BorderLayout BL = new BorderLayout();
        GridLayout GL = new GridLayout(4, 2);

        input.add(InvNo); //contains the input part
        input.add(InvVal);
        input.add(InvDate);
        input.add(InvDt_txt);
        input.add(CustName);
        input.add(CusName_txt);
        input.add(InvTotal);
        input.add(InvTotalVal);

        GridLayout Gl2 = new GridLayout(2, 1);
        righttbl.add(rightTabletitle);
        righttbl.add(InvItemsTable);
        righttbl.setLayout(Gl2);

        lefttbl.add(Lefttabletitle); //contains the table and its title
        lefttbl.add(InvsTable);
        lefttbl.setLayout(Gl2);

        GridLayout GLt = new GridLayout(4, 2);
        //GL.setHgap(0);

        input.setLayout(GLt); //done

        GridLayout GLtmain = new GridLayout(1, 2);
        // GL.setHgap(0);

        righttbl.add(new JScrollPane(InvItemsTable));

        lefttbl.add(new JScrollPane(InvsTable));

        rightbuttons.add(Save);
        rightbuttons.add(Cancel);
        rightbuttons.setLayout(GLtmain);

        leftbuttons.add(Create);
        leftbuttons.add(Delete);
        leftbuttons.setLayout(GLtmain);
        leftbuttons.setSize(200, 50);

        GridLayout rt = new GridLayout(3, 1);
        right.add(input);
        right.add(righttbl);
        right.add(rightbuttons);
        right.setLayout(rt);

        GridLayout lft = new GridLayout(2, 1);
        left.add(lefttbl);
        left.add(leftbuttons);
        left.setLayout(lft);

        add(left); //left and right are still empty
        add(right);
        //setLayout(new FlowLayout());
        setLayout(GLtmain);

        //GLtmain.setVgap(90);
        // GLtmain.setHgap(90);


        SaveFile.addActionListener(this);
        LoadFile.addActionListener(this);
        Create.addActionListener(this);
        Delete.addActionListener(this);
        Save.addActionListener(this);
        Cancel.addActionListener(this);

        Create.setActionCommand("Cr");
        Delete.setActionCommand("D");
        Save.setActionCommand("S");
        Cancel.setActionCommand("Cx");

        LoadFile.setActionCommand("Lf");
        SaveFile.setActionCommand("Sf");
    }


    public static void main(String[] args) {
        new project().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int invnom = 1; // count the number of existing invoices and increment it by 1
        switch (e.getActionCommand()) {

            case "Cr": //create
                DefaultTableModel model = (DefaultTableModel) InvItemsTable.getModel();
                model.addRow(new Object[]{InvVal.getText(), "", "", "", ""});

                //  model.addRow(new Object[] );
                //if user clicks on create then the invnom value is increased by 1 and assigned to invoince number
                //should create a new invoice by automatically increasing invoice number and providing it to the label InvVal
                //and blanks the entry screen on the right except for the number
                break;

            case "D":/*  completed
                InvDt_txt.setText("");
                CusName_txt.setText("");
                InvVal.setText("0");
                InvTotalVal.setText("0");*/
                deleteRow(InvsTable);
                if (Integer.parseInt(InvVal.getText()) > 0) {
                    invoicenum--;
                    InvVal.setText(Integer.toString(invoicenum));

                }

                //should delete selected row from the Invstable
                break;

            case "S":
                if(InvDt_txt.getText()!=null||CusName_txt.getText()!=null||InvVal.getText()!="0") {
                    invoicenum++;
                    InvVal.setText(Integer.toString(invoicenum));
                    insertRow();
                    findInvTotal();
                }
                break;

            case "Cx": //ths one is done //cancel button
                InvDt_txt.setText(null);
                CusName_txt.setText(null);
                deleteRow(InvItemsTable);
                if (invoicenum > 0 && (CusName_txt != null && InvDt_txt != null)) {
                    invoicenum--;
                }
                InvVal.setText(Integer.toString(invoicenum));
                break;

            case "Lf":

                Load("src/resources/InvoiceHeader.csv", InvsTable); //Loading is done only on the last row!
                Load("src/resources/InvoiceLine.csv", InvItemsTable);
                //loadFile();  : wrong insertion!
                JOptionPane.showMessageDialog(null, "insertion was successful");

                break;

            case "Sf":

                exportToCSV(InvsTable);
                exportToCSV(InvItemsTable);
                JOptionPane.showMessageDialog(null, "saved successfully");

        }
    }

    private void insertRow() {
        String invDate = InvDt_txt.getText();
        String Name = CusName_txt.getText();
        String invoiceNo = InvVal.getText();
        String total = InvTotalVal.getText();

        DefaultTableModel model = (DefaultTableModel) InvsTable.getModel();

        model.addRow(new Object[]{invoiceNo, invDate, Name, total});
    }

    private void deleteRow(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        if (table.getSelectedRow() != -1) {
            model.removeRow(table.getSelectedRow());
            JOptionPane.showMessageDialog(null, "Selected row deleted successfully");
        }
    }
    //when i select an invoice from the summarized invoice table tits data should appear in the right table
    //the summarized invoice table should have pre-existing data that are loaded from the load file button in the menu bar

    private void Load(String path,JTable table){
        String filePath = path;
        File file = new File(filePath);

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            // get the first line
            // get the columns name from the first line
            // set columns name to the jtable model
            DefaultTableModel model = (DefaultTableModel)table.getModel();

            // get lines from txt file
            Object[] tableLines = br.lines().toArray();

            // extract data from lines
            // set data to jtable model
            for(int i = 0; i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow = line.split(",");
                model.addRow(dataRow);
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

// use to save data into file

    private  boolean exportToCSV(JTable tableToExport) {


        try {

            String path ;
            JFileChooser fc = new JFileChooser();
            int result = fc.showSaveDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                path = fc.getSelectedFile().getPath();


            TableModel model = tableToExport.getModel();
            FileWriter csv = new FileWriter(new File(path));

            for (int i = 0; i < model.getColumnCount(); i++) {
                csv.write(model.getColumnName(i) + ",");
            }

            csv.write("\n");

            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    csv.write(model.getValueAt(i, j).toString() + ",");
                }
                csv.write("\n");
            }

            csv.close();
            return true;
        }} catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void findInvTotal(){
        double total = 0;
        int length = InvItemsTable.getRowCount();

        for(int i = 0 ; i<length;i++) {
            Object r= InvItemsTable.getModel().getValueAt(i, 2);
            double v = (double) r;

            total = v+total;
        }
        System.out.println(total);
        System.out.println(InvItemsTable.getModel().getValueAt(0, 3));
        //return total;
    }
}
//in saving file: create a new file of type csv and use jfile chooser to save file to a desired directory









